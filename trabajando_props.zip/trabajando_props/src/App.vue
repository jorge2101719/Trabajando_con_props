<template>
    <div id="app">
        <h1>{{titular}}</h1>
        <input type="text" id="info" v-model="tarea">
        <button v-on:click="agregar">Agregar tarea</button>

        <h2>{{lista}}</h2>

        <ul v-for="(tarea, index) in tareas" :key="index">
            <li v-on:click="borrar">
                {{tarea}}     
                <Eliminar @clickResponse="clickChild(index)"></Eliminar>
            </li>
        </ul>
    </div>
</template>

<script>
import Eliminar from './Eliminar.vue'

export default {
    name: "app",
    components: { Eliminar },
    data() {
        return {
            titular: 'Agregar una nueva tarea',
            lista: 'Lista',
            tarea: '',
            tareas: [],
            borrar: true,
        }
    },
    methods: {
        agregar: function() {
            this.tareas.push(this.tarea);
            this.tarea='';
        },
        clickChild: function(index) {
            this.tareas.splice(index, 1);
        },
        /*borrar: function(index) {
            if(this.index != -1) {
                this.tareas.splice(index, 1);
            }
        }*/
    }
};
</script>