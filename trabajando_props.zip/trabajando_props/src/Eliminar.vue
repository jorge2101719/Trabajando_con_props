<template>
  <span> 
    <button @click="clickResponse">Eliminar</button>
    {{mensaje}}
  </span>
</template>

<script>
export default {
    name: 'mensaje',
    props: {
        mesnaje: String,
    },
    methods: {
      clickResponse(index) {
        this.$emit('clickResponse', index);
      }
    },
}
</script>

<style>

</style>template